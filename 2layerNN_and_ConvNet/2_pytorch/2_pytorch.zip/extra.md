I tried Resnet-18 with pretrained = True and relaced the fully connected layer with 3 fully connected layers and got an accuracy of 95% (Rank:5 on leaderboard, Team: SYNERGY)

NAME: MUHAMMAD ZUBAIR IRSHAD
EMAIL: mirshad7@gatech.edu
BEST ACCURACY: 95%
EVALAI TEAM: SYNERGY
